# VacuumcleanerVacuumcleanerIdBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Updated name of the vacuumcleaner |  [optional]
**status** | **String** | Updated status of the vacuumcleaner |  [optional]
