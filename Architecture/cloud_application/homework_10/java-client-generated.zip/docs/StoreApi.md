# StoreApi

All URIs are relative to *https://virtserver.swaggerhub.com/geek_brans_student/VacuumCleaner/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteprogramma**](StoreApi.md#deleteprogramma) | **DELETE** /store/programma/{programmaId} | Delete purchase programma by ID
[**getInventory**](StoreApi.md#getInventory) | **GET** /store/inventory | Returns vacuumcleaner inventories by status
[**getprogrammaById**](StoreApi.md#getprogrammaById) | **GET** /store/programma/{programmaId} | Find purchase programma by ID
[**placeprogramma**](StoreApi.md#placeprogramma) | **POST** /store/programma | Place an programma for a vacuumcleaner

<a name="deleteprogramma"></a>
# **deleteprogramma**
> deleteprogramma(programmaId)

Delete purchase programma by ID

For valid response try integer IDs with positive integer value.\\ \\ Negative or non-integer values will generate API errors

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.StoreApi;


StoreApi apiInstance = new StoreApi();
Long programmaId = 789L; // Long | ID of the programma that needs to be deleted
try {
    apiInstance.deleteprogramma(programmaId);
} catch (ApiException e) {
    System.err.println("Exception when calling StoreApi#deleteprogramma");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **programmaId** | **Long**| ID of the programma that needs to be deleted | [enum: ]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="getInventory"></a>
# **getInventory**
> Map&lt;String, Integer&gt; getInventory()

Returns vacuumcleaner inventories by status

Returns a map of status codes to quantities

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.StoreApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

StoreApi apiInstance = new StoreApi();
try {
    Map<String, Integer> result = apiInstance.getInventory();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling StoreApi#getInventory");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

**Map&lt;String, Integer&gt;**

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getprogrammaById"></a>
# **getprogrammaById**
> Programma getprogrammaById(programmaId)

Find purchase programma by ID

For valid response try integer IDs with value &gt;&#x3D; 1 and &lt;&#x3D; 10.\\ \\ Other values will generated exceptions

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.StoreApi;


StoreApi apiInstance = new StoreApi();
Long programmaId = 789L; // Long | ID of vacuumcleaner that needs to be fetched
try {
    Programma result = apiInstance.getprogrammaById(programmaId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling StoreApi#getprogrammaById");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **programmaId** | **Long**| ID of vacuumcleaner that needs to be fetched | [enum: ]

### Return type

[**Programma**](Programma.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="placeprogramma"></a>
# **placeprogramma**
> Programma placeprogramma(body)

Place an programma for a vacuumcleaner

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.StoreApi;


StoreApi apiInstance = new StoreApi();
Programma body = new Programma(); // Programma | programma placed for purchasing the vacuumcleaner
try {
    Programma result = apiInstance.placeprogramma(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling StoreApi#placeprogramma");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Programma**](Programma.md)| programma placed for purchasing the vacuumcleaner |

### Return type

[**Programma**](Programma.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

