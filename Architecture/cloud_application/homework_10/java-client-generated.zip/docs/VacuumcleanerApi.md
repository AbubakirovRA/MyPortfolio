# VacuumcleanerApi

All URIs are relative to *https://virtserver.swaggerhub.com/geek_brans_student/VacuumCleaner/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addvacuumcleaner**](VacuumcleanerApi.md#addvacuumcleaner) | **POST** /vacuumcleaner | Add a new vacuumcleaner to the store
[**deletevacuumcleaner**](VacuumcleanerApi.md#deletevacuumcleaner) | **DELETE** /vacuumcleaner/{vacuumcleanerId} | Deletes a vacuumcleaner
[**findvacuumcleanersByStatus**](VacuumcleanerApi.md#findvacuumcleanersByStatus) | **GET** /vacuumcleaner/findByStatus | Finds vacuumcleaners by status
[**findvacuumcleanersByTags**](VacuumcleanerApi.md#findvacuumcleanersByTags) | **GET** /vacuumcleaner/findByTags | Finds vacuumcleaners by tags
[**getvacuumcleanerById**](VacuumcleanerApi.md#getvacuumcleanerById) | **GET** /vacuumcleaner/{vacuumcleanerId} | Find vacuumcleaner by ID
[**updatevacuumcleaner**](VacuumcleanerApi.md#updatevacuumcleaner) | **PUT** /vacuumcleaner | Update an existing vacuumcleaner
[**updatevacuumcleanerWithForm**](VacuumcleanerApi.md#updatevacuumcleanerWithForm) | **POST** /vacuumcleaner/{vacuumcleanerId} | Updates a vacuumcleaner in the store with form data
[**uploadFile**](VacuumcleanerApi.md#uploadFile) | **POST** /vacuumcleaner/{vacuumcleanerId}/uploadImage | uploads an image

<a name="addvacuumcleaner"></a>
# **addvacuumcleaner**
> addvacuumcleaner(body)

Add a new vacuumcleaner to the store

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.VacuumcleanerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: vacuumcleaner_auth
OAuth vacuumcleaner_auth = (OAuth) defaultClient.getAuthentication("vacuumcleaner_auth");
vacuumcleaner_auth.setAccessToken("YOUR ACCESS TOKEN");

VacuumcleanerApi apiInstance = new VacuumcleanerApi();
Vacuumcleaner body = new Vacuumcleaner(); // Vacuumcleaner | vacuumcleaner object that needs to be added to the store
try {
    apiInstance.addvacuumcleaner(body);
} catch (ApiException e) {
    System.err.println("Exception when calling VacuumcleanerApi#addvacuumcleaner");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Vacuumcleaner**](Vacuumcleaner.md)| vacuumcleaner object that needs to be added to the store |

### Return type

null (empty response body)

### Authorization

[vacuumcleaner_auth](../README.md#vacuumcleaner_auth)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

<a name="deletevacuumcleaner"></a>
# **deletevacuumcleaner**
> deletevacuumcleaner(vacuumcleanerId, apiKey)

Deletes a vacuumcleaner

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.VacuumcleanerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: vacuumcleaner_auth
OAuth vacuumcleaner_auth = (OAuth) defaultClient.getAuthentication("vacuumcleaner_auth");
vacuumcleaner_auth.setAccessToken("YOUR ACCESS TOKEN");

VacuumcleanerApi apiInstance = new VacuumcleanerApi();
Long vacuumcleanerId = 789L; // Long | vacuumcleaner id to delete
String apiKey = "apiKey_example"; // String | 
try {
    apiInstance.deletevacuumcleaner(vacuumcleanerId, apiKey);
} catch (ApiException e) {
    System.err.println("Exception when calling VacuumcleanerApi#deletevacuumcleaner");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **vacuumcleanerId** | **Long**| vacuumcleaner id to delete |
 **apiKey** | **String**|  | [optional]

### Return type

null (empty response body)

### Authorization

[vacuumcleaner_auth](../README.md#vacuumcleaner_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="findvacuumcleanersByStatus"></a>
# **findvacuumcleanersByStatus**
> List&lt;Vacuumcleaner&gt; findvacuumcleanersByStatus(status)

Finds vacuumcleaners by status

Multiple status values can be provided with comma separated strings

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.VacuumcleanerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: vacuumcleaner_auth
OAuth vacuumcleaner_auth = (OAuth) defaultClient.getAuthentication("vacuumcleaner_auth");
vacuumcleaner_auth.setAccessToken("YOUR ACCESS TOKEN");

VacuumcleanerApi apiInstance = new VacuumcleanerApi();
List<String> status = Arrays.asList("status_example"); // List<String> | Status values that need to be considered for filter
try {
    List<Vacuumcleaner> result = apiInstance.findvacuumcleanersByStatus(status);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling VacuumcleanerApi#findvacuumcleanersByStatus");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **status** | [**List&lt;String&gt;**](String.md)| Status values that need to be considered for filter | [enum: available, pending, sold]

### Return type

[**List&lt;Vacuumcleaner&gt;**](Vacuumcleaner.md)

### Authorization

[vacuumcleaner_auth](../README.md#vacuumcleaner_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="findvacuumcleanersByTags"></a>
# **findvacuumcleanersByTags**
> List&lt;Vacuumcleaner&gt; findvacuumcleanersByTags(tags)

Finds vacuumcleaners by tags

Muliple tags can be provided with comma separated strings. Use\\ \\ tag1, tag2, tag3 for testing.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.VacuumcleanerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: vacuumcleaner_auth
OAuth vacuumcleaner_auth = (OAuth) defaultClient.getAuthentication("vacuumcleaner_auth");
vacuumcleaner_auth.setAccessToken("YOUR ACCESS TOKEN");

VacuumcleanerApi apiInstance = new VacuumcleanerApi();
List<String> tags = Arrays.asList("tags_example"); // List<String> | Tags to filter by
try {
    List<Vacuumcleaner> result = apiInstance.findvacuumcleanersByTags(tags);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling VacuumcleanerApi#findvacuumcleanersByTags");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **tags** | [**List&lt;String&gt;**](String.md)| Tags to filter by |

### Return type

[**List&lt;Vacuumcleaner&gt;**](Vacuumcleaner.md)

### Authorization

[vacuumcleaner_auth](../README.md#vacuumcleaner_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="getvacuumcleanerById"></a>
# **getvacuumcleanerById**
> Vacuumcleaner getvacuumcleanerById(vacuumcleanerId)

Find vacuumcleaner by ID

Returns a single vacuumcleaner

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.VacuumcleanerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: api_key
ApiKeyAuth api_key = (ApiKeyAuth) defaultClient.getAuthentication("api_key");
api_key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//api_key.setApiKeyPrefix("Token");

VacuumcleanerApi apiInstance = new VacuumcleanerApi();
Long vacuumcleanerId = 789L; // Long | ID of vacuumcleaner to return
try {
    Vacuumcleaner result = apiInstance.getvacuumcleanerById(vacuumcleanerId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling VacuumcleanerApi#getvacuumcleanerById");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **vacuumcleanerId** | **Long**| ID of vacuumcleaner to return |

### Return type

[**Vacuumcleaner**](Vacuumcleaner.md)

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="updatevacuumcleaner"></a>
# **updatevacuumcleaner**
> updatevacuumcleaner(body)

Update an existing vacuumcleaner

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.VacuumcleanerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: vacuumcleaner_auth
OAuth vacuumcleaner_auth = (OAuth) defaultClient.getAuthentication("vacuumcleaner_auth");
vacuumcleaner_auth.setAccessToken("YOUR ACCESS TOKEN");

VacuumcleanerApi apiInstance = new VacuumcleanerApi();
Vacuumcleaner body = new Vacuumcleaner(); // Vacuumcleaner | vacuumcleaner object that needs to be added to the store
try {
    apiInstance.updatevacuumcleaner(body);
} catch (ApiException e) {
    System.err.println("Exception when calling VacuumcleanerApi#updatevacuumcleaner");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Vacuumcleaner**](Vacuumcleaner.md)| vacuumcleaner object that needs to be added to the store |

### Return type

null (empty response body)

### Authorization

[vacuumcleaner_auth](../README.md#vacuumcleaner_auth)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: Not defined

<a name="updatevacuumcleanerWithForm"></a>
# **updatevacuumcleanerWithForm**
> updatevacuumcleanerWithForm(vacuumcleanerId, name, status)

Updates a vacuumcleaner in the store with form data

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.VacuumcleanerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: vacuumcleaner_auth
OAuth vacuumcleaner_auth = (OAuth) defaultClient.getAuthentication("vacuumcleaner_auth");
vacuumcleaner_auth.setAccessToken("YOUR ACCESS TOKEN");

VacuumcleanerApi apiInstance = new VacuumcleanerApi();
Long vacuumcleanerId = 789L; // Long | ID of vacuumcleaner that needs to be updated
String name = "name_example"; // String | 
String status = "status_example"; // String | 
try {
    apiInstance.updatevacuumcleanerWithForm(vacuumcleanerId, name, status);
} catch (ApiException e) {
    System.err.println("Exception when calling VacuumcleanerApi#updatevacuumcleanerWithForm");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **vacuumcleanerId** | **Long**| ID of vacuumcleaner that needs to be updated |
 **name** | **String**|  | [optional]
 **status** | **String**|  | [optional]

### Return type

null (empty response body)

### Authorization

[vacuumcleaner_auth](../README.md#vacuumcleaner_auth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded
 - **Accept**: Not defined

<a name="uploadFile"></a>
# **uploadFile**
> ModelApiResponse uploadFile(vacuumcleanerId, body)

uploads an image

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.VacuumcleanerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure OAuth2 access token for authorization: vacuumcleaner_auth
OAuth vacuumcleaner_auth = (OAuth) defaultClient.getAuthentication("vacuumcleaner_auth");
vacuumcleaner_auth.setAccessToken("YOUR ACCESS TOKEN");

VacuumcleanerApi apiInstance = new VacuumcleanerApi();
Long vacuumcleanerId = 789L; // Long | ID of vacuumcleaner to update
Object body = null; // Object | 
try {
    ModelApiResponse result = apiInstance.uploadFile(vacuumcleanerId, body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling VacuumcleanerApi#uploadFile");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **vacuumcleanerId** | **Long**| ID of vacuumcleaner to update |
 **body** | **Object**|  | [optional]

### Return type

[**ModelApiResponse**](ModelApiResponse.md)

### Authorization

[vacuumcleaner_auth](../README.md#vacuumcleaner_auth)

### HTTP request headers

 - **Content-Type**: application/octet-stream
 - **Accept**: application/json

