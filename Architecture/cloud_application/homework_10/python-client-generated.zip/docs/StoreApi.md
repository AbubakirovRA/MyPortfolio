# swagger_client.StoreApi

All URIs are relative to *https://virtserver.swaggerhub.com/geek_brans_student/VacuumCleaner/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteprogramma**](StoreApi.md#deleteprogramma) | **DELETE** /store/programma/{programmaId} | Delete purchase programma by ID
[**get_inventory**](StoreApi.md#get_inventory) | **GET** /store/inventory | Returns vacuumcleaner inventories by status
[**getprogramma_by_id**](StoreApi.md#getprogramma_by_id) | **GET** /store/programma/{programmaId} | Find purchase programma by ID
[**placeprogramma**](StoreApi.md#placeprogramma) | **POST** /store/programma | Place an programma for a vacuumcleaner

# **deleteprogramma**
> deleteprogramma(programma_id)

Delete purchase programma by ID

For valid response try integer IDs with positive integer value.\\ \\ Negative or non-integer values will generate API errors

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.StoreApi()
programma_id = 789 # int | ID of the programma that needs to be deleted

try:
    # Delete purchase programma by ID
    api_instance.deleteprogramma(programma_id)
except ApiException as e:
    print("Exception when calling StoreApi->deleteprogramma: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **programma_id** | **int**| ID of the programma that needs to be deleted | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_inventory**
> dict(str, int) get_inventory()

Returns vacuumcleaner inventories by status

Returns a map of status codes to quantities

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: api_key
configuration = swagger_client.Configuration()
configuration.api_key['api_key'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['api_key'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.StoreApi(swagger_client.ApiClient(configuration))

try:
    # Returns vacuumcleaner inventories by status
    api_response = api_instance.get_inventory()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling StoreApi->get_inventory: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

**dict(str, int)**

### Authorization

[api_key](../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **getprogramma_by_id**
> Programma getprogramma_by_id(programma_id)

Find purchase programma by ID

For valid response try integer IDs with value >= 1 and <= 10.\\ \\ Other values will generated exceptions

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.StoreApi()
programma_id = 789 # int | ID of vacuumcleaner that needs to be fetched

try:
    # Find purchase programma by ID
    api_response = api_instance.getprogramma_by_id(programma_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling StoreApi->getprogramma_by_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **programma_id** | **int**| ID of vacuumcleaner that needs to be fetched | 

### Return type

[**Programma**](Programma.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **placeprogramma**
> Programma placeprogramma(body)

Place an programma for a vacuumcleaner

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.StoreApi()
body = swagger_client.Programma() # Programma | programma placed for purchasing the vacuumcleaner

try:
    # Place an programma for a vacuumcleaner
    api_response = api_instance.placeprogramma(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling StoreApi->placeprogramma: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Programma**](Programma.md)| programma placed for purchasing the vacuumcleaner | 

### Return type

[**Programma**](Programma.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

